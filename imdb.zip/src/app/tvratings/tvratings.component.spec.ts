import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TvratingsComponent } from './tvratings.component';

describe('TvratingsComponent', () => {
  let component: TvratingsComponent;
  let fixture: ComponentFixture<TvratingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TvratingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TvratingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
