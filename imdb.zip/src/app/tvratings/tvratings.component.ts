import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tvratings',
  templateUrl: './tvratings.component.html',
  styleUrls: ['./tvratings.component.css']
})
export class TvratingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
