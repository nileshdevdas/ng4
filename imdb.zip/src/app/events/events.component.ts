import { Component, OnInit } from '@angular/core';
import { MovielistService } from '../movielist.service';

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EventsComponent implements OnInit {
  version;
  constructor(private movieservice: MovielistService) { }

  ngOnInit() {
    this.version = this.movieservice.getVersion()
  }

}
