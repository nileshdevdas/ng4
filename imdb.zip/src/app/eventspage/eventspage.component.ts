import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eventspage',
  templateUrl: './eventspage.component.html',
  styleUrls: ['./eventspage.component.css']
})
export class EventspageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
