import { HighlihgterDirective } from './highlihgter.directive';

describe('HighlihgterDirective', () => {
  it('should create an instance', () => {
    const directive = new HighlihgterDirective();
    expect(directive).toBeTruthy();
  });
});
