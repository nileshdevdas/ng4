import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eventratings',
  templateUrl: './eventratings.component.html',
  styleUrls: ['./eventratings.component.css']
})
export class EventratingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
