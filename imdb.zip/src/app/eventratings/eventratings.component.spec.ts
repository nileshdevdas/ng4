import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventratingsComponent } from './eventratings.component';

describe('EventratingsComponent', () => {
  let component: EventratingsComponent;
  let fixture: ComponentFixture<EventratingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EventratingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventratingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
