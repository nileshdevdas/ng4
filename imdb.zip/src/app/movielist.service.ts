import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MovielistService {
  constructor(private http: HttpClient) {
    console.log('Intantiated........');
  }
  getVersion() {
    return 1.0;
  }

  getMoviesLists() {
    return this.http.get('http://www.mocky.io/v2/5d246df72f0000866f241921?mocky-delay=500ms');
  }
}









