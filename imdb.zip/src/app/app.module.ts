import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { MainlayoutComponent } from './mainlayout/mainlayout.component';
import { EventsComponent } from './events/events.component';
import { EventratingsComponent } from './eventratings/eventratings.component';
import { TvseriesComponent } from './tvseries/tvseries.component';
import { TvratingsComponent } from './tvratings/tvratings.component';
import { MoviedetailsComponent } from './moviedetails/moviedetails.component';
import { MovielistComponent } from './movielist/movielist.component';
import { MoviespageComponent } from './moviespage/moviespage.component';
import { EventspageComponent } from './eventspage/eventspage.component';
import { TvpageComponent } from './tvpage/tvpage.component';
import { HomepageComponent } from './homepage/homepage.component';
import { OopspageComponent } from './oopspage/oopspage.component';
import { RouterModule } from '@angular/router';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { FormsModule } from '@angular/forms';
import { AuthGuard } from './auth.guard';
import { CurrencyconvertorPipe } from './currencyconvertor.pipe';
import { HighlihgterDirective } from './highlihgter.directive';
import { SignupComponent } from './signup/signup.component';
const routes = [
  { path: '', component: HomepageComponent },
  { path: 'movies', component: MoviespageComponent, canActivate: [AuthGuard] },
  { path: 'tv', component: TvpageComponent },
  { path: 'events', component: EventspageComponent },
  { path: 'login', component: LoginpageComponent },
  { path: 'signup', component: SignupComponent },
  { path: '**', component: OopspageComponent }
];
@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FooterComponent,
    MainlayoutComponent,
    EventsComponent,
    EventratingsComponent,
    TvseriesComponent,
    TvratingsComponent,
    MoviedetailsComponent,
    MovielistComponent,
    MoviespageComponent,
    EventspageComponent,
    TvpageComponent,
    HomepageComponent,
    OopspageComponent,
    LoginpageComponent,
    CurrencyconvertorPipe,
    HighlihgterDirective,
    SignupComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
