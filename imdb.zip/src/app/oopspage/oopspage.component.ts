import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oopspage',
  templateUrl: './oopspage.component.html',
  styleUrls: ['./oopspage.component.css']
})
export class OopspageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
