import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PubsubService } from '../pubsub.service';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {
  username: string;
  password: string;
  constructor(private router: Router, private pubsub: PubsubService) { }
  handleLogin() {
    console.log(this.username);
    console.log(this.password);
    console.log("Login Clicked....");
  // store the that he is logged in so the next time the other people can have 
  // a common place to check whether the user is logged in or not 
    sessionStorage.setItem("micheal", this.username);
  
    // and here i am saying let all the subscriber know that the user has loggedin 
    this.pubsub.getLoginPublisher().next("LOGIN");
  
    // you navigage 
    this.router.navigate(['']);
  }
  ngOnInit() { }
}
