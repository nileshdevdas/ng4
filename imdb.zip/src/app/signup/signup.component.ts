import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  user: User = new User();
  constructor(private http: HttpClient) { }

  ngOnInit() {
  }

  handleSingnup() {
    this.http.post("someurl", JSON.stringify(this.user)).toPromise().then((result) => {
        // successs 
    }).catch((err) => {
        /// error 
    });
    console.log(this.user.firstname);
  }
}
export class User {
  firstname;
  lastname;
  email;
  phone;
  country;
}
