import { CurrencyconvertorPipe } from './currencyconvertor.pipe';

describe('CurrencyconvertorPipe', () => {
  it('create an instance', () => {
    const pipe = new CurrencyconvertorPipe();
    expect(pipe).toBeTruthy();
  });
});
