import { Directive, ElementRef, HostListener } from '@angular/core';
import { pipe, from } from 'rxjs';
import * as operators from 'rxjs/operators';
// <div appHighlighter> == selector : '[appHighlighter]'
// <appHighlighter></appHighlighter>  == selector : 'appHighlighter'
// <div class="appHighlighter"> == selector : '.appHighlighter'
@Directive({
  selector: 'appHighlihgter'
})
export class HighlihgterDirective {

  a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 4, 8, 8, 9, 8]

  constructor(private elem: ElementRef) {
    from(this.a).pipe(operators.filter(each => each < 5)).subscribe(el => console.log(el));
  }
  @HostListener("mouseout")
  whenMouseOutElement() {
    console.log("mouseout")
    this.elem.nativeElement.className = 'alert alert-danger';
  }
  @HostListener("mouseover")
  whenMouseOverELement() {
    console.log("mouseover")
    this.elem.nativeElement.className = 'alert alert-success';

  }


  @HostListener("mousedown")
  whenMouseDownnOverELement() {
    console.log("mouse down ")
  }

}
