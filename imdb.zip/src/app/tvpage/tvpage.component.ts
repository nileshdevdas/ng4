import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tvpage',
  templateUrl: './tvpage.component.html',
  styleUrls: ['./tvpage.component.css']
})
export class TvpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
