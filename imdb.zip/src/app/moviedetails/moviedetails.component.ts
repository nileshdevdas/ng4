import { Component, OnInit } from '@angular/core';
import { MovielistService } from '../movielist.service';
import { PubsubService } from '../pubsub.service';

@Component({
  selector: 'app-moviedetails',
  templateUrl: './moviedetails.component.html',
  styleUrls: ['./moviedetails.component.css']
})
export class MoviedetailsComponent implements OnInit {
  revent;
  constructor(private pubsubservice: PubsubService) { }

  ngOnInit() {
    this.pubsubservice.getSubscriber().subscribe((event) => {
      console.log("got event....")
      this.revent = event;
    });
  }

}


