import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tvseries',
  templateUrl: './tvseries.component.html',
  styleUrls: ['./tvseries.component.css']
})
export class TvseriesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
