import { Injectable } from '@angular/core';
import { Subject, BehaviorSubject, AsyncSubject, ReplaySubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PubsubService {
  private subject: Subject<any> = new Subject<any>();
  private loginSubject = new Subject();
  getSubscriber() {
    return this.subject.asObservable();
  }
  getPublisher() {
    return this.subject;
  }
  getLoginSubscriber() {
    return this.loginSubject.asObservable();
  }
  getLoginPublisher() {
    return this.loginSubject;
  }
}






